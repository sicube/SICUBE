#ifndef __DELAY_H__
#define __DELAY_H__

#ifdef __cplusplus
extern "C" {
#endif

void Delay10Ms(U16 m10s);
void Delay1Ms(U16 ms);

#ifdef __cplusplus
};
#endif
#endif