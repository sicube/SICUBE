// LanguageDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "3D Printer.h"
#include "3D PrinterDlg.h"
#include "LanguageDlg.h"


// LanguageDlg �Ի���

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// LanguageDlg dialog

LanguageDlg::LanguageDlg(CWnd* pParent /*=NULL*/)
	: CDialog(LanguageDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(LanguageDlg)
	//}}AFX_DATA_INIT
}

//LanguageDlg::~LanguageDlg()
//{
//}

void LanguageDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(LanguageDlg)
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_COMBO1, m_ComboBox1);
}


BEGIN_MESSAGE_MAP(LanguageDlg, CDialog)
    //{{AFX_MSG_MAP(LanguageDlg)
	ON_BN_CLICKED(IDOK,OnBnClickedOk)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////

// LanguageDlg message handlers


BOOL LanguageDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	_CWndCS(this);
	// TODO: Add extra initialization here
	LCID lcid = GetSystemDefaultLCID();

	UpdateData(FALSE);
	m_ComboBox1.SetCurSel(-1);
	m_ComboBox1.AddString(_CS("ConfigGeneral.English"));
	m_ComboBox1.AddString(_CS("ConfigGeneral.SimpChinese"));

	if((lcid&0xff) == 0x09)//English
		m_ComboBox1.SetCurSel(0);
	else if ((lcid & 0xff) == 0x04)//SimpChinese
		m_ComboBox1.SetCurSel(1);
	else
		m_ComboBox1.SetCurSel(0);
	UpdateData(TRUE);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣:  OCX ����ҳӦ���� FALSE
}


void LanguageDlg::OnBnClickedOk()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	//WritePrivateProfileString(_T("themes"), _T("Solution"), _T("English"), strConfig);
	unsigned char Index;
	Index = m_ComboBox1.GetCurSel();
	if (Index == 0)
		CMultiLanguage::SetCurrenLanguage("English");
	else if (Index == 1)
		CMultiLanguage::SetCurrenLanguage("SimpChinese");
	CDialog::OnOK();
}
