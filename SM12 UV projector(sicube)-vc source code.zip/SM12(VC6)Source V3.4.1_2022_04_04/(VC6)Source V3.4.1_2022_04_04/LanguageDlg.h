#include "afxwin.h"
#if !defined(AFX_LANGUAGEDLG_H__2C8C2BC9_7DD5_4E45_BD97_73BC0593EF96__INCLUDED_)
#define AFX_LANGUAGEDLG_H__2C8C2BC9_7DD5_4E45_BD97_73BC0593EF96__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// LanguageDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// LanguageDlg dialog

class LanguageDlg : public CDialog
{
// Construction
public:
	LanguageDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(LanguageDlg)
	enum { IDD = IDD_LANGUAGE };
    CComboBox m_ComboBox1;
	//}}AFX_DATA
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(LanguageDlg)
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

public:
// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(LanguageDlg)
	virtual BOOL OnInitDialog();
    afx_msg void OnBnClickedOk();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LANGUAGEDLG_H__2C8C2BC9_7DD5_4E45_BD97_73BC0593EF96__INCLUDED_)
