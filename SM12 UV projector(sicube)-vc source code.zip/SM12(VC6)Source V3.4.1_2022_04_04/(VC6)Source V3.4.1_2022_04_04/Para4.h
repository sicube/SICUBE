#if !defined(AFX_PARA4_H__9D2D1239_41C2_4C23_91D6_49A4A83CD2FE__INCLUDED_)
#define AFX_PARA4_H__9D2D1239_41C2_4C23_91D6_49A4A83CD2FE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Para4.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPara4 dialog

class CPara4 : public CDialog
{
// Construction
public:
	CPara4(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CPara4)
	enum { IDD = IDD_DIALOG4 };
	CComboBox	m_DeviceIndex;
	UINT	m_UvPower;
	float	m_Uv_k;
	float	m_Uv_b;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPara4)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPara4)
	virtual BOOL OnInitDialog();
	afx_msg void OnClose();
	afx_msg void OnSelchangeDeviceIndex();
	afx_msg void OnUvPowerSet();
	afx_msg void OnUvPowerGet();
	afx_msg void OnLedUvGet();
	afx_msg void OnUvParaSet();
	afx_msg void OnUvParaGet();
	afx_msg void OnChangeUvK();
	afx_msg void OnChangeUvB();
	afx_msg void OnUvAutoOn();
	afx_msg void OnUvAutoOff();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PARA4_H__9D2D1239_41C2_4C23_91D6_49A4A83CD2FE__INCLUDED_)
