#ifndef __CRC16_H__
#define __CRC16_H__

#ifdef __cplusplus
extern "C" {
#endif

unsigned short CRC16( const unsigned char* ptr, unsigned long len );

#ifdef __cplusplus
};
#endif


#endif